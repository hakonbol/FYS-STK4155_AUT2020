import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from mpl_toolkits.mplot3d import Axes3D
import matplotlib.pyplot as plt
from matplotlib import cm
from matplotlib.ticker import LinearLocator, FormatStrFormatter





def FrankeFunction(x,y,noisefactor):
        term1 = 0.75*np.exp(-(0.25*(9*x-2)**2) - 0.25*((9*y-2)**2))
        term2 = 0.75*np.exp(-((9*x+1)**2)/49.0 - 0.1*(9*y+1))
        term3 = 0.5*np.exp(-(9*x-7)**2/4.0 - 0.25*((9*y-3)**2))
        term4 = -0.2*np.exp(-(9*x-4)**2 - (9*y-7)**2)
        term5 = noisefactor*np.random.normal(0,1,(len(x),len(y)))
        return term1 + term2 + term3 + term4 + term5
        

def create_X(x, y, n ):
        if len(x.shape) > 1:
                x = np.ravel(x)
                y = np.ravel(y)

        N = len(x)
        l = int((n+1)*(n+2)/2)          # Number of elements in beta                                                               
        X = np.ones((N,l))

        for i in range(1,n+1):
                q = int((i)*(i+1)/2)
                for k in range(i+1):
                        X[:,q+k] = (x**(i-k))*(y**k)

        return X

def init_data(N,noisefactor):
    """
    Input: 
        N = datapoints, 
        noisefactor = scalar for gaussian distributed noise
    
    Output: 
        x_ = meshgrid of datapoints to compute the Franke Function in X directions
        y_ = meshgrid of datapoints to compute the Franke Function in Y directions
        z  = 2D array of the frankefunction
            
  
    x, y = np.random.uniform(0,1,size=(2,N))
    """
    x, y = np.linspace(0,1,N), np.linspace(0,1,N)
    x_,y_ = np.meshgrid(x,y)
    z = FrankeFunction(x_, y_, noisefactor)
    return x_, y_, z    
    

    
def PredictPlot(OLSbeta, N,n):
    # Plotting 
    x = np.linspace(0,1,N)
    y = np.linspace(0,1,N)
    x_,y_ = np.meshgrid(x,y)

    X = create_X(x_,y_,n)
    Z = X @ OLSbeta
    Z=Z.reshape(N,N)
    
    
    fig = plt.figure()
    ax = fig.gca(projection='3d')

    surf = ax.plot_surface(x_, y_, Z, cmap=cm.coolwarm,
                            linewidth=0, antialiased=False)
    # Customize the z axis.
    ax.set_zlim(-0.10, 1.40)
    ax.zaxis.set_major_locator(LinearLocator(10))
    ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

    # Add a color bar which maps values to colors.
    fig.colorbar(surf, shrink=0.5, aspect=5)
    plt.show()

def MSE(y,ypred):
    MSE = np.mean((y-ypred)**2)
    return MSE

def R2(y,ypred):
    return 1-np.sum((y-ypred)**2)/np.sum((y-np.mean(y))**2)


def ErrBiasVar(z_test,z_pred):
    """
    Takes in corresponding test and predicted data and computes the 
    error, bias and variance
    """
    error = np.mean( np.mean((z_test - z_pred)**2, axis=1, keepdims=True) )
    bias  = np.mean( (z_test - np.mean(z_pred, axis=1, keepdims=True))**2 )
    variance = np.mean( np.var(z_pred, axis=1, keepdims=True) )
    return error, bias, variance



def Scaling(X_train, X_test):
        (N, p) = X_train.shape
        if p > 1:
            scaler = StandardScaler()
            scaler.fit(X_train[:,1:])
            X_train = scaler.transform(X_train[:,1:])
            X_test = scaler.transform(X_test[:,1:])
            
            # Adding the intercept after the scaling, as the StandardScaler removes the 1s in the first column.
            intercept_train = np.ones((len(X_train),1))
            intercept_test = np.ones((len(X_test),1))
            X_train = np.concatenate((intercept_train,X_train),axis=1)
            X_test = np.concatenate((intercept_test,X_test),axis=1)
        else:
            X_train = X_train
            X_test = X_test
        return X_train, X_test

def SVDinv(A):
    ''' 
    Takes as input a numpy matrix A and returns inv(A) based on singular value decomposition (SVD).
    # SVD is numerically more stable than the inversion algorithms provided by
    # numpy and scipy.linalg at the cost of being slower. (Hjorth-Jensen, 2020) 
    '''
    
    U, s, VT = np.linalg.svd(A, full_matrices = False)
    invD = np.diag(1/s)
    UT = np.transpose(U); V = np.transpose(VT);
    return np.matmul(V,np.matmul(invD,UT))



def PredictPlot(OLSbeta, N,n):
    # Plotting 
    x = np.linspace(0,1,N)
    y = np.linspace(0,1,N)
    Z = np.empty((N,N))
    
    for i in range(N):
        X = create_X(x,y[i],n)
        Z[i,:] = X @ OLSbeta

    x_,y_ = np.meshgrid(x,y)


    fig = plt.figure()
    ax = fig.gca(projection='3d')

    surf = ax.plot_surface(x_, y_, Z, cmap=cm.coolwarm,
                            linewidth=0, antialiased=False)
    # Customize the z axis.
    ax.set_zlim(-0.10, 1.40)
    ax.zaxis.set_major_locator(LinearLocator(10))
    ax.zaxis.set_major_formatter(FormatStrFormatter('%.02f'))

    # Add a color bar which maps values to colors.
    fig.colorbar(surf, shrink=0.5, aspect=5)
    plt.show()


def Shuffle_Data(x,y):
    size = len(x)
    index = np.random.randint(1, size, size=size)
    x_ = x[index,:]
    y_ = y[index]
    return x_, y_

def OLSPredict(X_train, y_train):
    u, s, vt = np.linalg.svd(X_train, full_matrices=True)
    S = np.zeros((X_train.shape))
    S[:len(X_train[0,:]),:len(X_train[0,:])] = np.diag(s)
    XTX = vt.T.dot(S.T.dot(S)).dot(vt)

    # Estimating the Ordinary Least Squares Beta Matrix
    OLSbeta = np.linalg.pinv(XTX).dot(X_train.T).dot(y_train)
    return OLSbeta

def PreProcess(x_,y_,z, test_size, n):
    """
    Input:
        x_        : The meshgrid datapoints for x
        y_        : The meshgrid datapoints for y
        z         : The FrankeFunction datapoints
        test_size : The test_size for testing training datasplit
        n         : The maximum number of polynomial degree, (x+y)^n, that the functions can fit.
    """
    z = np.ravel(z)
    # Creating design matrix for the maximum polynomial degree. 
    X = create_X(x_,y_,n)

    # Test Train splitting of data
    X_train, X_test, z_train, z_test = train_test_split(X, z, test_size=0.2)

    # Scaling the train and test set
    #X_train, X_test = Scaling(X_train, X_test)
    return X_train, X_test, z_train, z_test 